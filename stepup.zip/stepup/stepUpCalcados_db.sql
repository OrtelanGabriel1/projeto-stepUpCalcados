-- drop database stepupcalcados_db;
CREATE DATABASE IF NOT EXISTS stepupcalcados_db;
USE stepupcalcados_db;

CREATE TABLE IF NOT EXISTS funcionario(
id_funcionario INT auto_increment primary KEY,
nome varchar(100) not null,
email varchar (100)not null unique,
senha varchar (100) not null,
tipo_funcionario varchar (100) not null
);

create table if not exists produto(
id_produto INT auto_increment primary KEY,
nome varchar(100) not null,
descricao varchar(200),
preco_venda decimal(10,2) not null,
preco_custo decimal(10,2) not null,
tamanho int not null,
cor varchar (100) not null,
genero varchar (100));
